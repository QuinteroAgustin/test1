- Explication du controle
J'ai fait les session pr n'accèder que au page que on peux (si on est connecté ou pas)

j'ai sécurisé les formulaires (password)

DEPLACEMENT DES CONNEXION sql dans le init

prepare execute pr l'inscription
affichage des info profil avec la session
ne peux pas eccèder au page si il n'est pas connecté
ne peux plus accèder au autres profils
